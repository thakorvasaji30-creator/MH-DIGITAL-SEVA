document.getElementById("year").textContent = new Date().getFullYear();
function customerLogin(){alert("Customer Login page will be connected to the backend in the next step.");}
function customerRegister(){alert("Customer Registration page will be connected to the backend in the next step.");}
